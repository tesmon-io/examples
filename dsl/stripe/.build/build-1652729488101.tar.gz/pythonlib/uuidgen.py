import uuid

def generate():
  return str(uuid.uuid4())
